# Flappy Bird (Dockerized)

## Run locally
docker-compose up --build

## URLs
Frontend: http://localhost:3000
Backend: http://localhost:5000/health
